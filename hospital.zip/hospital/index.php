<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Hospital - Pacientes</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="text-center mb-5">
      <h1 class="fw-bold">🏥 Módulo de Pacientes</h1>
    </div>
    <div class="d-grid gap-3 col-6 mx-auto">
      <a href="pacientes_form.php" class="btn btn-success btn-lg">➕ Registrar paciente</a>
      <a href="listar_pacientes.php" class="btn btn-primary btn-lg">📋 Listado de pacientes</a>
    </div>
  </div>
</body>
</html>
