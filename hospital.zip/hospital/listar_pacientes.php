<?php
require 'conexion.php';
$result = $conn->query("SELECT * FROM pacientes ORDER BY id_paciente DESC");
function e($s){return htmlspecialchars($s,ENT_QUOTES,'UTF-8');}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Listado de Pacientes</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="fw-bold">📋 Listado de Pacientes</h2>
      <a href="pacientes_form.php" class="btn btn-success">➕ Nuevo paciente</a>
    </div>

    <table class="table table-striped table-hover shadow-sm">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>Nombres</th>
          <th>Apellidos</th>
          <th>Fecha Nac.</th>
          <th>Documento</th>
          <th>Teléfono</th>
          <th>Creado</th>
        </tr>
      </thead>
      <tbody>
        <?php while($r = $result->fetch_assoc()): ?>
          <tr>
            <td><?= (int)$r['id_paciente'] ?></td>
            <td><?= e($r['nombres']) ?></td>
            <td><?= e($r['apellidos']) ?></td>
            <td><?= e($r['fecha_nacimiento']) ?></td>
            <td><?= e($r['documento']) ?></td>
            <td><?= e($r['telefono']) ?></td>
            <td><?= e($r['created_at']) ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>

    <div class="mt-4">
      <a href="index.php" class="btn btn-secondary">🏠 Volver al inicio</a>
    </div>
  </div>
</body>
</html>
<?php
$result->free();
$conn->close();
?>
