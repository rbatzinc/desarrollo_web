<?php
// Ajusta las credenciales a tu entorno (XAMPP/WAMP/MAMP)
$DB_HOST = '127.0.0.1';      // o 'localhost'
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'hospital_modulo';

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
  die('Error de conexión: ' . $conn->connect_error);
}

if (!$conn->set_charset('utf8mb4')) {
  // Si falla, al menos evita caracteres raros
  $conn->set_charset('utf8');
}
