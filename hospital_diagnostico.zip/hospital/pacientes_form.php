<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registrar Paciente</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="card shadow">
      <div class="card-body">
        <h2 class="card-title mb-4">➕ Registrar Paciente</h2>
        <form action="pacientes_guardar.php" method="POST">
          <div class="mb-3">
            <label class="form-label">Nombres</label>
            <input type="text" name="nombres" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Apellidos</label>
            <input type="text" name="apellidos" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Fecha de nacimiento</label>
            <input type="date" name="fecha_nacimiento" class="form-control">
          </div>
          <div class="mb-3">
            <label class="form-label">Documento</label>
            <input type="text" name="documento" class="form-control">
          </div>
          <div class="mb-3">
            <label class="form-label">Teléfono</label>
            <input type="text" name="telefono" class="form-control">
          </div>
          <button type="submit" class="btn btn-success">Guardar</button>
          <a href="index.php" class="btn btn-secondary">Cancelar</a>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
