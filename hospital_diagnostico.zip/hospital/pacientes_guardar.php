<?php
require 'conexion.php';

$nombres          = trim($_POST['nombres'] ?? '');
$apellidos        = trim($_POST['apellidos'] ?? '');
$fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
$documento        = trim($_POST['documento'] ?? '');
$telefono         = trim($_POST['telefono'] ?? '');

if ($nombres === '' || $apellidos === '') {
  die("❌ Faltan nombres o apellidos.");
}

$sql = "INSERT INTO pacientes (nombres, apellidos, fecha_nacimiento, documento, telefono)
        VALUES (?, ?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''))";

$stmt = $conn->prepare($sql);
$stmt->bind_param('sssss', $nombres, $apellidos, $fecha_nacimiento, $documento, $telefono);

if ($stmt->execute()) {
  $id = $stmt->insert_id;
} else {
  die("Error al guardar: " . $stmt->error);
}

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Paciente guardado</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5 text-center">
    <div class="alert alert-success shadow">
      <h4 class="alert-heading">✅ Paciente registrado con éxito</h4>
      <p>ID asignado: <strong><?= (int)$id ?></strong></p>
      <hr>
      <a href="pacientes_form.php" class="btn btn-success">Registrar otro</a>
      <a href="listar_pacientes.php" class="btn btn-primary">Ver listado</a>
      <a href="index.php" class="btn btn-secondary">Inicio</a>
    </div>
  </div>
</body>
</html>
